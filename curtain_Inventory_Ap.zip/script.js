// Initial inventory data (example)
let inventory = [
    { id: 1, name: "Velvet Damask", type: "roll", quantity: 5, lengthPerRoll: 50 }, // quantity is number of rolls
    { id: 2, name: "Sheer Voile", type: "meter", quantity: 120.5 }, // quantity is total meters
    { id: 3, name: "Cotton Print", type: "roll", quantity: 8, lengthPerRoll: 30 },
];

// Function to populate the item selection dropdown
function populateItemSelect() {
    const itemSelect = document.getElementById('item-select');
    itemSelect.innerHTML = '<option value="">-- Select Item --</option>'; // Default option
    inventory.forEach(item => {
        const option = document.createElement('option');
        option.value = item.id;
        // Display name and current quantity/type for clarity
        const typeInfo = item.type === 'roll' ? `${item.quantity} rolls (${item.lengthPerRoll}m/roll)` : `${item.quantity} m`;
        option.textContent = `${item.name} (${typeInfo})`;
        itemSelect.appendChild(option);
    });
}

// Function to display inventory and update dropdown
function displayInventory() {
    const inventoryListDiv = document.getElementById('inventory-list');
    inventoryListDiv.innerHTML = ''; // Clear previous content

    if (inventory.length === 0) {
        inventoryListDiv.innerHTML = '<p>Inventory is empty.</p>';
        return;
    }

    const table = document.createElement('table');
    table.innerHTML = `
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Type</th>
                <th>Quantity</th>
                <th>Length/Roll (m)</th>
                <th>Total Length (m)</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    `;
    const tbody = table.querySelector('tbody');

    inventory.forEach(item => {
        const row = tbody.insertRow();
        row.innerHTML = `
            <td>${item.id}</td>
            <td>${item.name}</td>
            <td>${item.type}</td>
            <td>${item.quantity} ${item.type === 'roll' ? 'rolls' : 'm'}</td>
            <td>${item.type === 'roll' ? item.lengthPerRoll : '-'}</td>
            <td>${item.type === 'roll' ? item.quantity * item.lengthPerRoll : item.quantity}</td>
        `;
    });

    inventoryListDiv.appendChild(table);
    populateItemSelect(); // Update the dropdown whenever inventory is displayed
}

// Function to add new item
function addItem(newItemData) {
    console.log("addItem called with data:", newItemData); // Log input data
    const statusP = document.getElementById('add-status');
    statusP.textContent = ''; // Clear previous status

    // Basic validation for common fields
    const quantityValue = parseFloat(newItemData.quantity);
    if (!newItemData.name || !newItemData.type || isNaN(quantityValue) || quantityValue < 0) {
        statusP.textContent = 'Error: Please fill Name, Type, and a valid non-negative Quantity.';
        statusP.style.color = 'red';
        console.error("Validation failed (common fields):", newItemData);
        return false;
    }

    let lengthPerRollValue = NaN; // Initialize to NaN, easier to check than null
    // Specific validation for 'roll' type
    if (newItemData.type === 'roll') {
        const rawLengthInput = newItemData.lengthPerRoll;
        console.log(`Type is roll. Validating Length per Roll. Input: "${rawLengthInput}"`);

        // 1. Check if the input string is empty or just whitespace
        if (!rawLengthInput || rawLengthInput.trim() === '') {
            statusP.textContent = 'Error: Length per Roll is required and cannot be empty for roll items.';
            statusP.style.color = 'red';
            console.error('Validation failed: Length per Roll input is empty or whitespace.');
            return false; // Stop execution
        }

        // 2. Attempt to parse the non-empty string
        lengthPerRollValue = parseFloat(rawLengthInput);

        // 3. Check if parsing failed (result is NaN) OR the parsed value is not positive
        if (isNaN(lengthPerRollValue) || lengthPerRollValue <= 0) {
             statusP.textContent = 'Error: Please enter a valid positive number for Length per Roll.';
             statusP.style.color = 'red';
             console.error(`Validation failed: Invalid number for Length per Roll. Input: "${rawLengthInput}", Parsed: ${lengthPerRollValue}`);
             return false; // Stop execution
        }
        // If we reach here, lengthPerRollValue is a valid positive number
        console.log("Length per Roll validation passed.");

    } else {
         lengthPerRollValue = NaN; // Ensure it's NaN if not a roll, for clarity
         console.log("Type is not roll, skipping Length per Roll validation.");
    }

    console.log("Validation passed for item:", newItemData.name); // Log validation success
    // Generate a unique ID (simple approach for now)
    const newId = inventory.length > 0 ? Math.max(...inventory.map(i => i.id)) + 1 : 1;

    const itemToAdd = {
        id: newId,
        name: newItemData.name,
        type: newItemData.type,
        quantity: quantityValue, // Use the already parsed quantity
    };

    if (itemToAdd.type === 'roll') {
        itemToAdd.lengthPerRoll = lengthPerRollValue; // Assign the validated number
    } else {
         // Ensure meter quantities are rounded if needed
         itemToAdd.quantity = Math.round(itemToAdd.quantity * 100) / 100;
    }


    inventory.push(itemToAdd);
    console.log("Item pushed to inventory array:", itemToAdd); // Log the item being pushed
    console.log("Current inventory:", JSON.stringify(inventory)); // Log the updated inventory array (using JSON for better readability)
    console.log("Added new item:", itemToAdd);
    statusP.textContent = `Successfully added ${itemToAdd.name}.`;
    statusP.style.color = 'green';
    displayInventory(); // Refresh the display
    return true;
}

// Function to update item quantity
function updateQuantity(itemId, change) {
    const item = inventory.find(i => i.id === parseInt(itemId));
    const statusP = document.getElementById('update-status');
    statusP.textContent = ''; // Clear previous status

    if (!item) {
        statusP.textContent = 'Error: Item not found.';
        statusP.style.color = 'red';
        console.error("Item not found for ID:", itemId);
        return false;
    }

    const quantityChange = parseFloat(change);
    if (isNaN(quantityChange)) {
         statusP.textContent = 'Error: Invalid quantity change.';
         statusP.style.color = 'red';
         console.error("Invalid quantity change:", change);
         return false;
    }

    // Ensure we don't go below zero
    if (item.quantity + quantityChange < 0) {
        statusP.textContent = `Error: Cannot remove ${-quantityChange} ${item.type === 'roll' ? 'rolls' : 'm'}. Only ${item.quantity} available.`;
        statusP.style.color = 'red';
        console.warn(`Attempted to reduce quantity below zero for item ${itemId}`);
        return false;
    }

    item.quantity += quantityChange;
    // Round meter quantities to avoid floating point issues if needed, e.g., 2 decimal places
    if (item.type === 'meter') {
        item.quantity = Math.round(item.quantity * 100) / 100;
    }

    console.log(`Updated quantity for item ${itemId}. New quantity: ${item.quantity}`);
    statusP.textContent = `Successfully updated ${item.name}.`;
    statusP.style.color = 'green';
    displayInventory(); // Refresh the inventory display
    return true;
}

// Initial display load
// Event Listeners for Update Buttons
document.addEventListener('DOMContentLoaded', () => {
    const itemTypeSelect = document.getElementById('item-type');
    const rollSpecificDiv = document.getElementById('roll-specific');
    const lengthPerRollInput = document.getElementById('length-per-roll');
    const addItemForm = document.getElementById('add-item-form');
    const addStatusP = document.getElementById('add-status');

    // Show/hide Length per Roll based on type selection
    itemTypeSelect.addEventListener('change', (event) => {
        const selectedType = event.target.value;
        console.log(`Item type changed to: ${selectedType}`); // Log type change

        // Ensure we have the correct element references inside the listener scope
        const rollDiv = document.getElementById('roll-specific');
        const lengthInput = document.getElementById('length-per-roll');

        if (!rollDiv || !lengthInput) {
            console.error("Error: Could not find roll-specific elements inside event listener!");
            return;
        }

        if (selectedType === 'roll') {
            console.log("Setting roll-specific div display to 'block'");
            rollDiv.style.display = 'block';
            lengthInput.required = true;
        } else {
            console.log("Setting roll-specific div display to 'none'");
            rollDiv.style.display = 'none';
            lengthInput.required = false;
            lengthInput.value = ''; // Clear value if switching away
        }
    });

    // Initial display load
    displayInventory();

    const addBtn = document.getElementById('add-quantity-btn');
    const removeBtn = document.getElementById('remove-quantity-btn');
    const itemSelect = document.getElementById('item-select');
    const quantityChangeInput = document.getElementById('quantity-change');
    const statusP = document.getElementById('update-status');

    addBtn.addEventListener('click', () => {
        const itemId = itemSelect.value;
        const change = quantityChangeInput.value;
        if (!itemId) {
            statusP.textContent = 'Please select an item.';
            statusP.style.color = 'orange';
            return;
        }
        if (change === '' || parseFloat(change) <= 0) {
             statusP.textContent = 'Please enter a positive quantity to add.';
             statusP.style.color = 'orange';
             return;
        }
        updateQuantity(itemId, change);
        quantityChangeInput.value = ''; // Clear input after update
    });

    removeBtn.addEventListener('click', () => {
        const itemId = itemSelect.value;
        const change = quantityChangeInput.value;
         if (!itemId) {
            statusP.textContent = 'Please select an item.';
            statusP.style.color = 'orange';
            return;
        }
       if (change === '' || parseFloat(change) <= 0) {
             statusP.textContent = 'Please enter a positive quantity to remove.';
             statusP.style.color = 'orange';
             return;
        }
        // Pass negative value for removal
        updateQuantity(itemId, -parseFloat(change));
        quantityChangeInput.value = ''; // Clear input after update
    });

    // Add Item Form Submission (Moved to correct scope)
    addItemForm.addEventListener('submit', (event) => {
        event.preventDefault(); // Prevent default form submission
        console.log("Add Item form submitted."); // Log form submission

        const newItemData = {
            name: document.getElementById('item-name').value.trim(),
            type: document.getElementById('item-type').value,
            quantity: document.getElementById('item-quantity').value,
            lengthPerRoll: document.getElementById('length-per-roll').value
        };
        console.log("Form data collected:", newItemData); // Log collected form data

        if (addItem(newItemData)) {
            addItemForm.reset(); // Clear the form on success
            // Explicitly hide roll-specific div after adding, regardless of type selected before reset
            rollSpecificDiv.style.display = 'none';
            lengthPerRollInput.required = false;
            console.log("Form reset, hiding roll-specific div.");
        }
    });
});